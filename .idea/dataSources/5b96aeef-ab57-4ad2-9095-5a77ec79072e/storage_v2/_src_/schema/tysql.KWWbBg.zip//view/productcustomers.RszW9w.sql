create definer = root@`%` view productcustomers as
select `tysql`.`customers`.`cust_name` AS `cust_name`, `tysql`.`customers`.`cust_contact` AS `cust_contact`, `tysql`.`orderitems`.`prod_id` AS `prod_id`
from `tysql`.`customers`
       join `tysql`.`orders`
       join `tysql`.`orderitems`
where ((`tysql`.`customers`.`cust_id` = `tysql`.`orders`.`cust_id`) and (`tysql`.`orderitems`.`order_num` = `tysql`.`orders`.`order_num`));

