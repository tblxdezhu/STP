create
  definer = root@`%` procedure ordertotal(IN onumber int, IN taxable tinyint(1), OUT ototal decimal(8, 2))
begin
  declare total decimal(8,2);
  declare taxrate int default 6;

  -- get the order total
  select sum(item_price*quantity) from OrderItems where order_num = onumber
  into total;

  -- Is this taxable?
  if taxable then
    select total+(total/100*taxrate) into total;
  end if;

  select total into ototal;
end;

