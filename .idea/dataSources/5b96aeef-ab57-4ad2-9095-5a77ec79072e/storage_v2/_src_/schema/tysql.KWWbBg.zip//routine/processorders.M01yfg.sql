create
  definer = root@`%` procedure processorders()
begin
  declare done boolean default 0;
  declare o int;
  declare t decimal(8,2);

  -- 声明游标
  declare ordernumbers cursor for select order_num from Orders;
  -- 定义了一个CONTINUE HANDLER
  declare continue handler for sqlstate '02000' set done=1;
  -- 创建一个表存储结果
  create table if not exists ordertotals (order_num int,total decimal(8,2));
  -- 打开游标
  open ordernumbers;
  -- 遍历所有行
  repeat
        fetch ordernumbers into o;
        call ordertotal(o,1,t);
        insert into ordertotals(order_num, total) VALUES (o,t);
  until done end repeat;
  close ordernumbers;
end;

